class Response:
    def __init__(
            self,
            version, #string
            code, #number
            reason, #string
            headers, #dict, the keys are the header names and values are the header values 
            text, #string
    ):
        self.version = version
        self.code = code
        self.reason = reason
        self.headers = headers
        self.text = text

    def to_http_response(self):
        headers_str = '\r\n'.join([f'{key}: {value}' for key, value in self.headers.items()])
        http_response = f'{self.version} {self.code} {self.reason}\r\n{headers_str}\r\n\r\n{self.text}'
        return http_response