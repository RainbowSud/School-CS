import socket
from router import router
from encoder import decode_request, encode_response
from middleware import logging_middleware, required_headers_middleware, is_static, static_files_middleware

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.bind(("127.0.0.1", 6969))
    s.listen()
    print("listening on port 6969")

    while True:
        connection, addr = s.accept()
        with connection:
            data = connection.recv(8192)
            if not data:
                connection.close()
                continue
            print(str(data, "UTF-8"))
            request = decode_request(data)
            if is_static(request.uri):
                middleware_chain = static_files_middleware(router)
                middleware_chain = logging_middleware(middleware_chain)
                response = middleware_chain(request)
                response_data = encode_response(response)
                connection.send(bytes(response_data, "UTF-8"))
            else: 
                middleware_chain = required_headers_middleware(router)
                middleware_chain = logging_middleware(middleware_chain)
                response = middleware_chain(request)
                response_data = encode_response(response)
                connection.send(bytes(response_data, "UTF-8"))
