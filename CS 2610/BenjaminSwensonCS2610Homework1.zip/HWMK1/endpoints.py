from response import Response
import datetime
from middleware import logging_middleware

@logging_middleware
def index(request):
    with open("templates/index.html") as f:
        return Response(
            version="HTTP/1.1",
            code=200,
            reason="Ok",
            headers={
            },
            text= f.read()
        )


def about(request):
    with open("templates/about.html") as f:
        return Response(
            version="HTTP/1.1",
            code=200,
            reason="Ok",
            headers={
            },
            text= f.read()
        )

def experience(request):
    with open("templates/experience.html") as f:
        return Response(
            version="HTTP/1.1",
            code=200,
            reason="Ok",
            headers={
            },
            text= f.read()
        )
    
def projects(request):
    with open("templates/projects.html") as f:
        return Response(
            version="HTTP/1.1",
            code=200,
            reason="Ok",
            headers={
            },
            text= f.read()
        )

def code(request):
    with open("static/code.js") as f:
        return Response(
            version="HTTP/1.1",
            code=200,
            reason="Ok",
            headers={
            },
            text= f.read()
        )
    
def styles(request):
    with open("static/styles.css") as f:
        return Response(
            version="HTTP/1.1",
            code=200,
            reason="Ok",
            headers={
            },
            text= f.read()
        )