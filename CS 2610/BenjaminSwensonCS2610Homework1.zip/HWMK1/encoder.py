from request import Request

def decode_request(http_string):
    request = http_string.decode("UTF-8")
    return Request(
        method=request.split(' ')[0],
        version=request.split(' ')[2],
        uri=request.split(' ')[1],
        headers={
        },
        text=""
    )

def encode_response(response):
    return response.to_http_response()