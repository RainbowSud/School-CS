import datetime
from request import Request

def logging_middleware(next):
    def middleware(request):
        print(f"{request.method} {request.uri}")
        response = next(request)
        print(f"{response.code} {response.reason}")
        print(response.headers)
        return response

    return middleware

def required_headers_middleware(next):
    def middleware(request):
        response = next(request)
        headers = {
            "Connection": "close",
            "Server": "Benjamin's Server",
            "Cache-Control": "no-cache",
            "Date": str(datetime.datetime.today()),
            "Content-Type": "text/html",
            "Content-Length": len(response.text)
        }
        headers.update(response.headers)
        response.headers = headers
        return response

    return middleware

def is_static(request):
    if ".js" in request:
        return True
    if ".css" in request:
        return True
    else:
        return False
    
def static_files_middleware(next):
    def middleware(request):
        response = next(request)
        if ".js" in request.uri:
            headers = {
                "Connection": "close",
                "Server": "Benjamin's Server",
                "Cache-Control": "no-cache",
                "Date": str(datetime.datetime.today()),
                "Content-Type": "text/javascript",
                "Content-Length": len(response.text)
            }
            headers.update(response.headers)
            response.headers = headers
        if ".css" in request.uri:
            headers = {
                "Connection": "close",
                "Server": "Benjamin's Server",
                "Cache-Control": "no-cache",
                "Date": str(datetime.datetime.today()),
                "Content-Type": "text/css",
                "Content-Length": len(response.text)
            }
            headers.update(response.headers)
            response.headers = headers
        return response   
    return middleware

