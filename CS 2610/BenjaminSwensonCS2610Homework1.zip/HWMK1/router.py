from endpoints import about, experience, projects, index, code, styles
from response import Response
import datetime

def router(request):
    if request.uri == "/":
        return index(request)
    if request.uri == "/about.html":
        return about(request)
    if request.uri == "/experience.html":
        return experience(request)
    if request.uri == "/projects.html": 
        return projects(request)
    if request.uri == "/static/code.js":
        return code(request)
    if request.uri == "/static/styles.css":
        return styles(request)
    else:
        return Response(
        version="HTTP/1.1",
        code=404,
        reason="Not found",
        headers={
            "Connection": "close",
            "Server": "Benjamin's Server",
            "Cache-Control": "no-cache",
            "Date": str(datetime.datetime.today()),
            "Content-Type": "text/html",
            "Content-Length": "50" 
        },
        text="<h1>Error 404 - Page not found</h1>"
    )